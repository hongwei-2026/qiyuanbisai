# ntops-copilot — 九齿 .skill 创新挑战（初赛可执行版）

让 AI 智能体按 **「读规格 → 选模板 → 写内核 → 自检 → 测通 → 交 PR」** 闭环完成 [ntops](https://github.com/InfiniTensor/ntops) 算子开发。

## 安装 Skill（Cursor / Agent）

将 `skills/ntops-copilot` 复制到：

- 项目：`.cursor/skills/ntops-copilot/`
- 或全局：`~/.cursor/skills/ntops-copilot/`

## 快速验证（v0.3 实用版）

```bash
# 环境自检
python scripts/doctor.py

# 一键任务流（推荐）
python scripts/run_task.py --task silu --ntops-root d:\启元\ntops-master\ntops-master

# 或分步
python scripts/scaffold_kernel.py --name gelu --pattern unary --style ntops --out /tmp/gelu.py
python scripts/preflight.py /tmp/gelu.py --kernel
```

**v0.3 突破点**：对齐 ntops 真实 `premake` 写法 + `run_task` 一条命令开工 + `formulas.md` 公式速查。

## 身份信息

| 用途 | 填写 |
|------|------|
| 启元 / InfiniTensor 报名姓名 | 于鸿伟 |
| GitHub 仓库、PR 分支、commit | **hongwei-2026** |

## 初赛执行（建议流程）

1. 在 `ntops` 仓库实现 2-3 个算子任务（可参考 `skills/ntops-copilot/tasks/`）。
2. 每个任务跑 `preflight` + `pytest`，保存结果截图。
3. 跑一轮 A/B 评测并生成统计：

```bash
python scripts/eval_ab.py --input docs/ab_runs.csv --output docs/AB_Report.md
```

4. 将过程和结果更新到 `docs/InitialRound.md`。
5. 重新打包初赛附件（默认打初赛包）：

```bash
python scripts/pack_submission.py --stage initial
```

## 提交大赛表单时填写

| 字段 | 填什么 |
|------|--------|
| Github 仓库 | `https://github.com/hongwei-2026/qiyuan-skill-ntops-copilot`（push 后使用你的实际 URL） |
| PR 链接 **或** Commit 链接 | 任选其一（建议用含 `skills/ntops-copilot` 的 commit） |
| 附件 | 运行 `python scripts/pack_submission.py --stage initial` 生成的 zip |

## 目录

```
skills/ntops-copilot/     # 核心 .skill
scripts/                  # 脚手架 + 自检（可执行，非空泛文档）
docs/Proposal.md          # Proposal 正文（导出 PDF 放进 zip）
docs/InitialRound.md      # 初赛结果与A/B评测
HONOR_CODE.md
REFERENCE.md
```

## 许可

Apache-2.0（与 NineToothed / ntops 生态一致）
