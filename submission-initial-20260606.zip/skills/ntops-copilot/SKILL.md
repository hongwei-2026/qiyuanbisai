---
name: ntops-copilot
description: >-
  NineToothed ntops operator copilot: one-command run_task, env doctor, ntops-native
  premake+element_wise scaffolds, formula cookbook, preflight, pytest and contest PR.
  Use for ntops, NineToothed, 九齿, 算子开发, premake, element_wise, CUDA pytest,
  2026-spring PR, InfiniCore.
---

# ntops-copilot

让 Agent **更快、更准** 完成 ntops 九齿算子开发。核心不是堆文档，而是：

1. **对齐 ntops 真实写法**（`premake` + `element_wise.arrangement`）
2. **一条命令开工**（`run_task.py`）
3. **公式速查 + 自检护栏**（少返工、少写成 Triton）

## 何时启用

`ntops`、`NineToothed`、`九齿`、`算子`、`premake`、`kernels/`、`pytest`、`2026-spring` PR。

## 30 秒上手（人类/Agent 都适用）

```bash
# 0) 环境自检（GPU 机先 source conda）
python scripts/doctor.py

# 1) 一条命令：读任务卡 -> 生成 kernel/torch 骨架 -> preflight -> 打印后续步骤
python scripts/run_task.py --task silu --ntops-root /path/to/ntops --contest-id T1-1-X

# 2) 只改 application() 公式（查 formulas.md），再测
cd /path/to/ntops && pytest tests/ -k silu -q
```

GPU 云（如 SeetaCloud）常见要先：
```bash
source /root/miniconda3/bin/activate base
```

## ntops 真实范式（必须优先）

ntops **不是** ninetoothed-examples 那种顶层 `ninetoothed.make(...)`。

标准结构：

```python
from ntops.kernels.element_wise import arrangement

def application(input, output):
    output = ...  # noqa: F841

def premake(ndim, dtype=None, block_size=None):
    arrangement_ = functools.partial(arrangement, block_size=block_size)
    tensors = (Tensor(ndim, dtype=dtype), Tensor(ndim, dtype=dtype))
    return arrangement_, application, tensors
```

torch 封装：

```python
kernel = _cached_make(ntops.kernels.<op>.premake, input.ndim)
kernel(input, output)
```

生成骨架时用：`--style ntops`（默认）。

## 标准工作流

### Step 0 — doctor

```bash
python scripts/doctor.py
```

确认：`ninetoothed`、`torch`、`CUDA`（跑 pytest 需要）、`ntops` 是否就绪。

### Step 1 — 选任务

读 `tasks/task_<op>.yaml`，或让用户给算子名 + 公式。

### Step 2 — run_task（推荐）

```bash
python scripts/run_task.py --task <op> --ntops-root <ntops> --contest-id <赛题号>
```

自动生成：
- `src/ntops/kernels/<op>.py`
- `src/ntops/torch/<op>.py`（若给了 ntops-root）

### Step 3 — 只改 application()

查 `formulas.md`，对照 `reference_kernel` 链接。**不要改 premake 结构。**

### Step 4 — 注册 + 测试

- 更新 `src/ntops/kernels/__init__.py`
- 更新 `src/ntops/torch/__init__.py`
- `python scripts/preflight.py src/ntops/kernels/<op>.py --kernel`
- `pytest tests/ -k <op> -q`

### Step 5 — PR

- 分支：`2026-spring-hongwei-2026-<赛题号>`
- 标题：`[2026春季][赛题号] hongwei-2026`
- 模板：`templates/PR_DESCRIPTION.md`

## 硬性原则

1. **正确性 > 性能**
2. **禁止 Triton 交卷**：发现 `@triton.jit` 必须改 NineToothed
3. **禁止抄袭**：更新 `REFERENCE.md`
4. **preflight 不过禁止 PR**

## 常见错误

| 现象 | 处理 |
|------|------|
| 写了 examples 风格 `make` | 改用 `--style ntops` 重新 scaffold |
| pytest 全 skipped | 无 CUDA；换 GPU 机并 `doctor` 确认 |
| `python3 not found` | 用 conda：`source .../activate base && python` |
| application 公式错 | 查 `formulas.md` + 官方同名 kernel |

## 脚本

| 脚本 | 作用 |
|------|------|
| `run_task.py` | **一键任务流**（最常用） |
| `doctor.py` | 环境/CUDA/依赖自检 |
| `scaffold_kernel.py` | 生成 kernel（默认 ntops 风格） |
| `scaffold_torch.py` | 生成 torch 封装 |
| `preflight.py` | 拦截 Triton/结构错误 |
| `eval_ab.py` | A/B 评测汇总 |

## 资源

- `formulas.md` — 公式速查
- `reference.md` — API 与目录
- `examples.md` — silu 端到端
- `tasks/*.yaml` — 任务卡
