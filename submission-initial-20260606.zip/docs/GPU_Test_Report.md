# GPU 环境测试报告

**日期**：2026-06-06  
**选手**：于鸿伟（hongwei-2026）  
**环境**：SeetaCloud `connect.westb.seetacloud.com:48605`

## 硬件与 CUDA

```
GPU: NVIDIA GeForce RTX 4090
Driver: 580.105.08
CUDA: 13.0 (nvidia-smi)
torch: 2.8.0+cu128
torch.cuda.is_available(): True
```

## Skill 测试（/root/work/skill）

```bash
source /root/miniconda3/bin/activate base
cd /root/work/skill
python scripts/preflight.py skills/ntops-copilot          # OK
python scripts/scaffold_kernel.py --name test_silu --pattern unary --out /tmp/test_silu.py
python scripts/preflight.py /tmp/test_silu.py --kernel    # OK
```

## ntops pytest（/root/work/ntops）

```bash
source /root/miniconda3/bin/activate base
cd /root/work/ntops
python -m pip install -e .
pytest -q -k silu        # 8 passed, 920 deselected in 8.68s
pytest -q tests/test_add.py  # 8 passed in 8.36s
```

## 结论

- `ntops-copilot` skill 在 GPU Linux 环境可正常完成结构自检与脚手架生成。
- 配套 ntops 官方测试在 CUDA 可用时可通过 silu/add 正确性测试。
- 初赛材料可附本报告作为「可实现」证据。
