# 初赛报告：ntops-copilot

## 1. 选手信息

- 姓名（启元报名）：于鸿伟
- GitHub ID：hongwei-2026
- Skill：`ntops-copilot`

## 2. 初赛目标

- 将通用 Agent 在 ntops 任务中的常见失败（写错范式、漏流程、无自检）前移到本地拦截。
- 用 A/B 对比验证：加载 skill 后，任务通过率和效率是否提升。

## 3. 实施内容

- Skill 工作流：`read spec -> scaffold -> implement -> preflight -> pytest -> PR material`
- 可执行脚本：
  - `scripts/scaffold_kernel.py`
  - `scripts/preflight.py`
  - `scripts/eval_ab.py`
- 任务卡：
  - `skills/ntops-copilot/tasks/TEMPLATE.yaml`
  - `skills/ntops-copilot/tasks/task_silu.yaml`
  - `skills/ntops-copilot/tasks/task_add.yaml`

## 4. A/B 实验方法

- Baseline：不加载 `ntops-copilot`
- Treatment：加载 `ntops-copilot`
- 统一记录字段见 `docs/ab_runs.csv`
- 自动汇总命令：

```bash
python scripts/eval_ab.py --input docs/ab_runs.csv --output docs/AB_Report.md
```

## 5. 实验结果

将 `docs/AB_Report.md` 中汇总指标粘贴到本节，并附 1-2 张关键截图（pytest/preflight）。

> 说明：你当前 Windows 环境缺 `triton`，本地 `pytest` 可能无法运行；因此本节 A/B 数据需要在组委会评测环境或 WSL/Linux 环境重新生成并替换。

## 6. 结论

- 实用性：该 skill 可直接复用于后续算子任务，降低人工返工。
- 可实现性：依赖轻量，无需自建云服务；可在本地与组委会环境复现。
- 后续计划：补充复杂算子任务卡（如 norm/attention）与错误样例库。
